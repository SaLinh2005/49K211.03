import React, { useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import './MentorEvaluationModal.css';

// KẾT NỐI SUPABASE
const supabaseUrl = 'https://amaqvdpfwplrezzevodh.supabase.co';
const supabaseKey = 'sb_publishable_VEJHAFPUd2VdVzLMhoKssg_p2Wboo5n'; 
const supabase = createClient(supabaseUrl, supabaseKey);

interface MentorEvaluationModalProps {
    isOpen: boolean;
    onClose: () => void;
    mentorId?: string; 
    mentorName?: string; 
    mentorDept?: string;
}

const MentorEvaluationModal: React.FC<MentorEvaluationModalProps> = ({ 
    isOpen, 
    onClose,
    // NHÚNG ID THẬT CỦA MENTOR (Lấy từ dòng 1 trong ảnh)
    mentorId = '681beeb0-91ef-4c2c-8be7-0b5d5339d9af', 
    mentorName = "TS. Nguyễn Văn A",
    mentorDept = "Khoa Marketing"
}) => {
    const [rating, setRating] = useState<number>(0);
    const [hoverRating, setHoverRating] = useState<number>(0);
    const [feedback, setFeedback] = useState<string>('');
    const [showError, setShowError] = useState<boolean>(false);
    const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
    const [isSuccess, setIsSuccess] = useState<boolean>(false);

    if (!isOpen) return null;

    const handleClose = () => {
        setRating(0);
        setHoverRating(0);
        setFeedback('');
        setShowError(false);
        setIsSuccess(false);
        onClose();
    };

    const handleSubmit = async () => {
        if (rating === 0) {
            setShowError(true);
            return;
        }
        setShowError(false);
        setIsSubmitting(true);

        try {
            const { error } = await supabase
                .from('reviews')
                .insert([
                    {
                        mentor_id: mentorId, 
                        // NHÚNG ID THẬT CỦA SINH VIÊN (Lấy từ account aaaaa)
                        student_id: 'd59c27e8-e323-4a58-8e30-fd9a92437bfa', 
                        rating: rating,
                        comment: feedback 
                    }
                ]);

            if (error) {
                throw error;
            }
            
            setIsSuccess(true);
        } catch (error: any) {
            console.error("Lỗi Supabase:", error.message);
            alert("Lỗi không thể gửi đánh giá: " + error.message);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="modal-overlay">
            {isSuccess ? (
                <div className="success-content">
                    <div className="success-icon-bg">
                        <div className="success-icon">✓</div>
                    </div>
                    <h2>Đánh giá thành công!</h2>
                    <p>Cảm ơn bạn đã đóng góp ý kiến cho cộng đồng <strong>UNIMENTOR</strong>.</p>
                    <button className="btn-submit" onClick={handleClose}>ĐÓNG</button>
                </div>
            ) : (
                <div className="modal-content">
                    <div className="modal-header">
                        <div>
                            <h3>Đánh giá & Nhận xét Mentor</h3>
                            <p>Trường Đại học Kinh tế - ĐHĐN (DUE)</p>
                        </div>
                        <button className="close-btn" onClick={handleClose}>&times;</button>
                    </div>
                    
                    <div className="modal-body">
                        <div className="mentor-info">
                            <img src="https://i.pravatar.cc/150?img=11" alt="Avatar" className="mentor-avatar" />
                            <div>
                                <div className="mentor-name">{mentorName}</div>
                                <div className="mentor-dept">{mentorDept}</div>
                            </div>
                        </div>

                        <div className="rating-section">
                            <div className="rating-title">Đánh giá chung</div>
                            <div className="rating-row">
                                <div className="stars">
                                    {[1, 2, 3, 4, 5].map((star) => (
                                        <span 
                                            key={star}
                                            className={`star ${star <= (hoverRating || rating) ? 'selected' : ''}`}
                                            onMouseEnter={() => setHoverRating(star)}
                                            onMouseLeave={() => setHoverRating(0)}
                                            onClick={() => {
                                                setRating(star);
                                                setShowError(false);
                                            }}
                                        >
                                            ★
                                        </span>
                                    ))}
                                </div>
                                {showError && <div className="error-msg">⚠️ Vui lòng chọn sao</div>}
                            </div>
                            <div className="rating-hint">Chạm vào sao để đánh giá</div>
                        </div>

                        <div className="feedback-section">
                            <div className="rating-title">Phản hồi chi tiết (Không bắt buộc)</div>
                            <textarea 
                                placeholder="Hãy chia sẻ trải nghiệm của bạn..."
                                value={feedback}
                                onChange={(e) => setFeedback(e.target.value)}
                            ></textarea>
                        </div>

                        <button className="btn-submit" onClick={handleSubmit} disabled={isSubmitting}>
                            {isSubmitting ? 'ĐANG GỬI...' : 'GỬI ĐÁNH GIÁ'}
                        </button>
                        <button className="btn-cancel" onClick={handleClose}>Hủy</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default MentorEvaluationModal;